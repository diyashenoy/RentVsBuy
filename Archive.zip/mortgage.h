//
// Created by Diya Shenoy on 2019-10-16.
//

#ifndef RENTVSBUY_MORTGAGE_H
#define RENTVSBUY_MORTGAGE_H

double mortgage_calculator(double& principle, double& term, double& rate);

#endif //RENTVSBUY_MORTGAGE_H

