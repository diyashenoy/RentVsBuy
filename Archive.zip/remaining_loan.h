//
// Created by Diya Shenoy on 2019-10-19.
//

#ifndef RENTVSBUY_REMAINING_LOAN_H
#define RENTVSBUY_REMAINING_LOAN_H

double loan_calc(double& monthly_mortgage, double& remaining_loan, double loan_rate);

#endif //RENTVSBUY_REMAINING_LOAN_H
