//
// Created by Diya Shenoy on 2019-10-17.
//

#ifndef RENTVSBUY_TAX_H
#define RENTVSBUY_TAX_H

double calc_tax(double& tax_rate, double& current_value);

#endif //RENTVSBUY_TAX_H
