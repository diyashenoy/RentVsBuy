//
// Created by Diya Shenoy on 2019-10-16.
//

#ifndef RENTVSBUY_BUYING_TRANSPORTATION_H
#define RENTVSBUY_BUYING_TRANSPORTATION_H

double home_transportation();
double rent_transportation();

#endif //RENTVSBUY_BUYING_TRANSPORTATION_H
