//
// Created by Diya Shenoy on 2019-10-16.
//

#ifndef RENTVSBUY_APPRECIATION_H
#define RENTVSBUY_APPRECIATION_H

double appreciation(double& purchase_price, double& appreciation_rate);

#endif //RENTVSBUY_APPRECIATION_H
